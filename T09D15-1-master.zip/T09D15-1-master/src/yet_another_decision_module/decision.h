#define GOLDEN_RATIO 0.666






            
